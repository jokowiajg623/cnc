#pragma once

#define HTTP_SERVER "84.46.251.176"
#define HTTP_PORT 80

#define TFTP_SERVER "84.46.251.176"
